<?php
$name = readline("Как вас зовут? ");
$age = readline("Ок $name, сколько вам лет? ");

echo "Вас зовут $name, вам $age лет.";