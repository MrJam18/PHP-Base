<?php 
$title = 'Документ №1';
$header1 = 'Информация обо мне.';
$year = 1994;

include 'secondTemplate.php';